import './style.css';
import { auth } from './firebase';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { renderAuth } from './components/auth';
import { createGameLoop, WEAPON_BASE_COSTS, STORE_ITEMS } from './gameLoop';
import { renderCratesTab } from './components/crates';
import { renderWarehouseTab } from './components/warehouse';
import { renderUpgradesTab } from './components/upgrades';
import { renderRankings } from './components/rankings';

const app = document.querySelector('#app') as HTMLElement;
let activeGameInstance: any = null;

document.addEventListener('contextmenu', (e) => e.preventDefault());
document.addEventListener('dragstart', (e) => e.preventDefault());

onAuthStateChanged(auth, async (user) => {
  if (!user) {
    if (activeGameInstance?.cleanup) await activeGameInstance.cleanup();
    renderAuth(app, (loggedInUser) => {
      initGame(loggedInUser);
    });
  } else {
    initGame(user);
  }
});

async function initGame(user: any) {
  activeGameInstance = await createGameLoop(user, (state, isAfk) => {
    updateUI(state, isAfk);
  });

  renderGameLayout(user, activeGameInstance);
}

function renderGameLayout(user: any, game: any) {
  app.innerHTML = `
    <div class="w-screen h-dvh app-bg flex flex-col font-sans select-none overflow-hidden p-4 md:p-6 relative">
      <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-[var(--accent)]/10 via-[var(--bg-app)] to-[var(--bg-app)] pointer-events-none"></div>

      <!-- Banner Anti-AFK -->
      <div id="afk-banner" class="hidden relative z-20 mb-2 bg-amber-500/20 border border-amber-500/40 text-amber-300 px-4 py-2 rounded-xl text-xs font-mono text-center animate-pulse flex-shrink-0">
        ⚠️ MODO AFK: Producción pasiva de drones pausada. Interactúa o adquiere un Buff Pasivo.
      </div>

      <!-- Header Principal -->
      <header class="relative z-10 card-glass border rounded-2xl p-4 flex flex-col md:flex-row items-center justify-between gap-4 shadow-xl mb-4 flex-shrink-0">
        <div class="flex items-center gap-3">
          <div class="w-3 h-3 rounded-full accent-bg animate-pulse"></div>
          <div>
            <div class="text-[10px] text-[var(--text-muted)] font-mono tracking-widest">NAVE DE COMBATE</div>
            <div id="nav-username" class="font-['Orbitron'] font-bold text-sm accent-text truncate max-w-[200px]">${user.displayName || 'Operativo'}</div>
          </div>
        </div>

        <!-- HUD de Buffs y Compañeros -->
        <div id="active-buffs-hud" class="flex items-center gap-2 flex-wrap justify-center"></div>

        <div class="flex items-center gap-2 flex-wrap justify-center">
          <select id="theme-selector" class="app-bg border border-[var(--border-color)] rounded-xl px-3 py-2 text-xs font-mono text-[var(--text-main)] focus:outline-none focus:border-[var(--accent)] cursor-pointer">
            <option value="">☀️ Nova (Claro)</option>
            <option value="cyber-dark">🌙 Cyber Dark</option>
            <option value="matrix">🟢 Matrix Green</option>
            <option value="nature">🌿 Naturaleza (Eco)</option>
            <option value="neon-purple">🔮 Neón Púrpura</option>
            <option value="sunset">🌅 Sunset Cyber</option>
          </select>

          <button id="warehouse-tab-btn" class="px-3 py-2 card-glass border border-[var(--border-color)] rounded-xl text-xs font-mono accent-text hover:border-[var(--accent)] transition cursor-pointer flex items-center gap-1">
            📦 Almacén
          </button>

          <button id="upgrades-tab-btn" class="px-3 py-2 card-glass border border-[var(--border-color)] rounded-xl text-xs font-mono accent-text hover:border-[var(--accent)] transition cursor-pointer flex items-center gap-1">
            💎 Sintonizador
          </button>

          <button id="crates-tab-btn" class="px-3 py-2 card-glass border border-[var(--border-color)] rounded-xl text-xs font-mono accent-text hover:border-[var(--accent)] transition cursor-pointer flex items-center gap-1">
            🎁 Cajas
          </button>

          <button id="rankings-btn" class="px-3.5 py-2 card-glass border border-[var(--border-color)] rounded-xl text-xs font-mono accent-text hover:border-[var(--accent)] transition cursor-pointer">
            🏆 Rankings
          </button>
          
          <button id="logout-btn" class="px-3.5 py-2 bg-red-500/10 border border-red-500/30 rounded-xl text-xs font-mono text-red-400 hover:bg-red-500/25 transition cursor-pointer">
            Salir
          </button>
        </div>
      </header>

      <!-- Main Fullscreen Layout sin Scroll Global -->
      <main class="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-4 max-w-6xl mx-auto w-full items-center flex-grow overflow-hidden pb-4">
        
        <!-- Panel Izquierdo: Arma Principal (Click = Disparo) -->
        <div class="lg:col-span-5 flex flex-col items-center justify-center gap-5 card-glass border rounded-3xl p-6 shadow-2xl text-center">
          <div>
            <div class="text-xs text-[var(--text-muted)] font-mono tracking-widest mb-1">NANITAS RECOLECTADAS</div>
            <div id="nanites-counter" class="text-3xl md:text-4xl font-['Orbitron'] font-black accent-text tracking-wider">0.00</div>
            <div id="passive-income-display" class="text-xs font-mono text-[var(--text-muted)] mt-1">+0 / seg (Drones)</div>
          </div>

          <button id="click-btn" class="relative w-44 h-44 md:w-52 md:h-52 rounded-full app-bg border-4 border-[var(--accent)] flex flex-col items-center justify-center gap-2 shadow-[0_0_30px_rgba(245,158,11,0.2)] hover:scale-105 active:scale-95 transition-all cursor-pointer group">
            <div class="absolute inset-0 rounded-full accent-bg opacity-10 group-hover:opacity-20 transition"></div>
            <svg xmlns="http://www.w3.org/2000/svg" class="w-10 h-10 accent-text animate-pulse" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
            <span class="font-['Orbitron'] font-black text-xs tracking-widest accent-text">DISPARAR ARMA</span>
          </button>
        </div>

        <!-- Panel Derecho: Armas Base, Cristales y Tienda con Scroll Interno Estricto -->
        <div class="lg:col-span-7 card-glass border rounded-3xl p-5 md:p-6 shadow-2xl flex flex-col gap-4 overflow-hidden h-full max-h-[60vh] lg:max-h-[72vh]">
          <div class="flex items-center justify-between border-b border-[var(--border-color)] pb-3 flex-shrink-0">
            <h2 class="font-['Orbitron'] font-bold text-base accent-text tracking-wide">ARMAMENTO Y TIENDA BASE</h2>
          </div>

          <div class="flex flex-col gap-3 overflow-y-auto pr-1 flex-grow">
            <!-- Blaster Láser (Niveles Base 0 a 3) -->
            <div class="app-bg border border-[var(--border-color)] rounded-2xl p-3.5 flex items-center justify-between gap-3">
              <div>
                <div class="font-['Orbitron'] font-bold text-sm text-[var(--text-main)]">Blaster Láser</div>
                <div id="blaster-info" class="text-xs font-mono text-[var(--text-muted)] mt-0.5">Nivel Base: 0 / 3</div>
                <div class="text-[10px] font-mono accent-text mt-0.5">+1 Daño base por clic</div>
              </div>
              <button id="buy-blaster" class="px-4 py-2.5 accent-bg hover:opacity-90 text-slate-950 font-['Orbitron'] font-bold text-xs rounded-xl transition accent-glow cursor-pointer flex-shrink-0">
                Mejorar (20 ⚡)
              </button>
            </div>

            <!-- Cañón de Plasma -->
            <div class="app-bg border border-[var(--border-color)] rounded-2xl p-3.5 flex items-center justify-between gap-3">
              <div>
                <div class="font-['Orbitron'] font-bold text-sm text-[var(--text-main)]">Cañón de Plasma</div>
                <div id="plasma-info" class="text-xs font-mono text-[var(--text-muted)] mt-0.5">Nivel Base: 0 / 3</div>
                <div class="text-[10px] font-mono accent-text mt-0.5">+5 Daño base por clic</div>
              </div>
              <button id="buy-plasma" class="px-4 py-2.5 accent-bg hover:opacity-90 text-slate-950 font-['Orbitron'] font-bold text-xs rounded-xl transition accent-glow cursor-pointer flex-shrink-0">
                Mejorar (150 ⚡)
              </button>
            </div>

            <!-- Disruptor Cuántico -->
            <div class="app-bg border border-[var(--border-color)] rounded-2xl p-3.5 flex items-center justify-between gap-3">
              <div>
                <div class="font-['Orbitron'] font-bold text-sm text-[var(--text-main)]">Disruptor Cuántico</div>
                <div id="quantum-info" class="text-xs font-mono text-[var(--text-muted)] mt-0.5">Nivel Base: 0 / 3</div>
                <div class="text-[10px] font-mono accent-text mt-0.5">+25 Daño base por clic</div>
              </div>
              <button id="buy-quantum" class="px-4 py-2.5 accent-bg hover:opacity-90 text-slate-950 font-['Orbitron'] font-bold text-xs rounded-xl transition accent-glow cursor-pointer flex-shrink-0">
                Mejorar (1.2 K ⚡)
              </button>
            </div>

            <div class="border-t border-[var(--border-color)] pt-2 mt-1">
              <div class="text-[11px] font-['Orbitron'] font-bold accent-text mb-2">MERCADO RÁPIDO DE SUMINISTROS</div>
            </div>

            <!-- Llave -->
            <div class="app-bg border border-[var(--border-color)] rounded-2xl p-3.5 flex items-center justify-between gap-3">
              <div>
                <div class="font-['Orbitron'] font-bold text-sm text-[var(--text-main)]">Llave de Cifrado 🔑</div>
                <div class="text-[10px] font-mono accent-text mt-0.5">Abre cofres del inventario</div>
              </div>
              <button id="buy-key" class="px-4 py-2.5 card-glass border accent-border hover:accent-bg hover:text-slate-950 accent-text font-['Orbitron'] font-bold text-xs rounded-xl transition cursor-pointer flex-shrink-0">
                Comprar (250 ⚡)
              </button>
            </div>

            <!-- Cristal de Mejora -->
            <div class="app-bg border border-[var(--border-color)] rounded-2xl p-3.5 flex items-center justify-between gap-3">
              <div>
                <div class="font-['Orbitron'] font-bold text-sm text-[var(--text-main)]">Cristal de Mejora 💎</div>
                <div class="text-[10px] font-mono accent-text mt-0.5">Necesario para sintonizar armas en el taller</div>
              </div>
              <button id="buy-crystal" class="px-4 py-2.5 card-glass border accent-border hover:accent-bg hover:text-slate-950 accent-text font-['Orbitron'] font-bold text-xs rounded-xl transition cursor-pointer flex-shrink-0">
                Comprar (60 ⚡)
              </button>
            </div>
          </div>
        </div>

      </main>

      <footer class="relative z-10 text-center text-[10px] text-[var(--text-muted)] font-mono flex-shrink-0 pt-1">
        Cyber-Forge Space Engine v4.0 • Sistema en Línea
      </footer>
    </div>
  `;

  document.querySelector('#click-btn')?.addEventListener('click', () => game.click());
  
  document.querySelector('#buy-blaster')?.addEventListener('click', () => {
    const success = game.buyWeaponLevel('blaster');
    if (!success) alert('Nanitas insuficientes o nivel máximo base (3) alcanzado. Usa el Sintonizador para niveles superiores.');
  });
  document.querySelector('#buy-plasma')?.addEventListener('click', () => {
    const success = game.buyWeaponLevel('plasmaCannon');
    if (!success) alert('Nanitas insuficientes o nivel máximo base (3) alcanzado.');
  });
  document.querySelector('#buy-quantum')?.addEventListener('click', () => {
    const success = game.buyWeaponLevel('quantumDisruptor');
    if (!success) alert('Nanitas insuficientes o nivel máximo base (3) alcanzado.');
  });

  document.querySelector('#buy-key')?.addEventListener('click', () => game.buyStoreItem('key'));
  document.querySelector('#buy-crystal')?.addEventListener('click', () => game.buyStoreItem('upgradeCrystal'));

  document.querySelector('#warehouse-tab-btn')?.addEventListener('click', () => {
    renderWarehouseTab(app, game, () => renderGameLayout(user, game));
  });

  document.querySelector('#upgrades-tab-btn')?.addEventListener('click', () => {
    renderUpgradesTab(app, game, () => renderGameLayout(user, game));
  });

  document.querySelector('#crates-tab-btn')?.addEventListener('click', () => {
    renderCratesTab(app, game, () => renderGameLayout(user, game));
  });

  document.querySelector('#rankings-btn')?.addEventListener('click', () => {
    renderRankings(app, user, () => renderGameLayout(user, game));
  });

  document.querySelector('#logout-btn')?.addEventListener('click', async () => {
    if (activeGameInstance?.cleanup) await activeGameInstance.cleanup();
    signOut(auth);
  });

  const themeSelector = document.querySelector('#theme-selector') as HTMLSelectElement;
  const savedTheme = localStorage.getItem('cyberforge_theme') || '';
  if (themeSelector) {
    themeSelector.value = savedTheme;
    document.body.className = savedTheme;
  }
  themeSelector?.addEventListener('change', (e) => {
    const val = (e.target as HTMLSelectElement).value;
    document.body.className = val;
    localStorage.setItem('cyberforge_theme', val);
  });

  updateUI(game.getState(), game.isAfk());
}

function updateUI(state: any, isAfk: boolean = false) {
  const nanitesCounter = document.querySelector('#nanites-counter');
  const passiveIncomeDisplay = document.querySelector('#passive-income-display');
  const afkBanner = document.querySelector('#afk-banner');
  const activeBuffsHud = document.querySelector('#active-buffs-hud');
  
  const blasterInfo = document.querySelector('#blaster-info');
  const plasmaInfo = document.querySelector('#plasma-info');
  const quantumInfo = document.querySelector('#quantum-info');

  if (nanitesCounter) nanitesCounter.textContent = formatNumber(state.nanites);

  const now = Date.now();
  const clickBuffRemaining = Math.max(0, state.buffs.clickBoostExpiresAt - now);
  const passiveBuffRemaining = Math.max(0, state.buffs.passiveBoostExpiresAt - now);
  const hasPassiveBuff = passiveBuffRemaining > 0;

  if (passiveIncomeDisplay) {
    passiveIncomeDisplay.textContent = (isAfk && !hasPassiveBuff) ? `+0 / seg (AFK Pausado)` : `+${formatNumber(state.passiveIncome)} / seg (Drones)`;
  }

  if (afkBanner) {
    if (isAfk && !hasPassiveBuff) {
      afkBanner.classList.remove('hidden');
    } else {
      afkBanner.classList.add('hidden');
    }
  }

  if (activeBuffsHud) {
    let hudHtml = '';
    if (clickBuffRemaining > 0) {
      hudHtml += `<div class="card-glass border accent-border rounded-xl px-2.5 py-1 text-[11px] font-mono accent-text">⚡ Clics x2: ${formatTime(clickBuffRemaining)}</div>`;
    }
    if (passiveBuffRemaining > 0) {
      hudHtml += `<div class="card-glass border accent-border rounded-xl px-2.5 py-1 text-[11px] font-mono accent-text">🛡️ Pasivo x2 (AFK): ${formatTime(passiveBuffRemaining)}</div>`;
    }
    state.activeCompanions.forEach((compId: string) => {
      const comp = state.companions.find((c: any) => c.id === compId);
      if (comp) {
        hudHtml += `<div class="card-glass border accent-border rounded-xl px-2.5 py-1 text-[11px] font-mono accent-text">🤖 ${comp.name}</div>`;
      }
    });
    activeBuffsHud.innerHTML = hudHtml;
  }

  if (blasterInfo) blasterInfo.textContent = `Nivel: ${state.weapons.blaster.level} / 20`;
  if (plasmaInfo) plasmaInfo.textContent = `Nivel: ${state.weapons.plasmaCannon.level} / 20`;
  if (quantumInfo) quantumInfo.textContent = `Nivel: ${state.weapons.quantumDisruptor.level} / 20`;
}

function formatNumber(num: number): string {
  if (num >= 1e9) return (num / 1e9).toFixed(2) + ' B';
  if (num >= 1e6) return (num / 1e6).toFixed(2) + ' M';
  if (num >= 1e3) return (num / 1e3).toFixed(2) + ' K';
  return Math.floor(num).toLocaleString();
}

function formatTime(ms: number): string {
  const totalSeconds = Math.floor(ms / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  if (hours > 0) return `${hours}h ${minutes}m`;
  if (minutes > 0) return `${minutes}m ${seconds}s`;
  return `${seconds}s`;
}