import { GameState } from './types';

const SAVE_KEY = 'cyber_forge_save_v1';

export const defaultState: GameState = {
  nanites: 0,
  totalNanitesProduced: 0,
  clickPower: 1,
  factories: {
    drone: 0,
    assembler: 0,
    colossus: 0
  },
  lastUpdate: Date.now()
};

export function loadGame(): GameState {
  const saved = localStorage.getItem(SAVE_KEY);
  if (!saved) return { ...defaultState };
  try {
    const parsed = JSON.parse(saved);
    return { ...defaultState, ...parsed };
  } catch (e) {
    console.error('Error loading save:', e);
    return { ...defaultState };
  }
}

export function saveGame(state: GameState): void {
  localStorage.setItem(SAVE_KEY, JSON.stringify(state));
}
