export interface GameState {
  nanites: number;
  totalNanitesProduced: number;
  clickPower: number;
  factories: {
    drone: number;
    assembler: number;
    colossus: number;
  };
  lastUpdate: number;
}

export interface UserProfile {
  uid: string;
  username: string;
  score: number;
  updatedAt: number;
}
