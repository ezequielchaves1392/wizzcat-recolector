export function renderWarehouseTab(container: HTMLElement, game: any, onBack: () => void) {
  let activeTab = 'all'; // 'all', 'weapons', 'consumables', 'companions'
  let selectedSlotIndex: number | null = null;
  let sourceDragIndex: number | null = null;

  const renderTemplate = () => {
    const state = game.getState();
    const slots = state.warehouseSlots;

    container.innerHTML = `
      <div class="w-screen h-dvh app-bg flex flex-col items-center p-4 md:p-6 font-sans select-none overflow-hidden">
        <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-[var(--accent)]/10 via-[var(--bg-app)] to-[var(--bg-app)] pointer-events-none"></div>
        
        <div class="relative z-10 max-w-5xl w-full flex flex-col gap-4 my-auto max-h-full">
          <!-- Cabecera -->
          <div class="flex items-center justify-between flex-shrink-0">
            <button id="back-btn" class="px-4 py-2 card-glass border border-[var(--border-color)] rounded-xl text-xs font-mono accent-text hover:border-[var(--accent)] transition cursor-pointer">
              ← Volver al Comando
            </button>
            <h2 class="text-base md:text-xl font-['Orbitron'] font-black accent-text tracking-wider text-right">ALMACÉN Y GESTIÓN DE INVENTARIO</h2>
          </div>

          <!-- Pestañas de Filtrado y Capacidad -->
          <div class="flex flex-col md:flex-row items-center justify-between gap-3 flex-shrink-0">
            <div class="flex items-center gap-2 flex-wrap">
              <button data-tab="all" class="tab-btn px-4 py-2 rounded-xl text-xs font-mono font-bold transition cursor-pointer ${activeTab === 'all' ? 'accent-bg text-slate-950 accent-glow' : 'card-glass border border-[var(--border-color)] text-[var(--text-muted)]'}">
                Todo (${slots.filter((s: any) => s !== null).length})
              </button>
              <button data-tab="weapons" class="tab-btn px-4 py-2 rounded-xl text-xs font-mono font-bold transition cursor-pointer ${activeTab === 'weapons' ? 'accent-bg text-slate-950 accent-glow' : 'card-glass border border-[var(--border-color)] text-[var(--text-muted)]'}">
                🔫 Armas
              </button>
              <button data-tab="consumables" class="tab-btn px-4 py-2 rounded-xl text-xs font-mono font-bold transition cursor-pointer ${activeTab === 'consumables' ? 'accent-bg text-slate-950 accent-glow' : 'card-glass border border-[var(--border-color)] text-[var(--text-muted)]'}">
                📦 Consumibles
              </button>
              <button data-tab="companions" class="tab-btn px-4 py-2 rounded-xl text-xs font-mono font-bold transition cursor-pointer ${activeTab === 'companions' ? 'accent-bg text-slate-950 accent-glow' : 'card-glass border border-[var(--border-color)] text-[var(--text-muted)]'}">
                🤖 Compañeros
              </button>
            </div>

            <div class="flex items-center gap-3 card-glass border rounded-2xl px-4 py-2">
              <div class="text-[10px] text-[var(--text-muted)] font-mono">CAPACIDAD: <span class="font-bold accent-text">${slots.filter((s: any) => s !== null).length} / ${state.warehouseCapacity}</span></div>
              <button id="expand-warehouse-btn" class="px-3 py-1.5 accent-bg text-slate-950 font-['Orbitron'] font-bold text-[10px] rounded-lg hover:opacity-90 transition cursor-pointer">
                Ampliar (+5 slots - 500 ⚡)
              </button>
            </div>
          </div>

          <!-- Contenido Principal: Grid + Panel de Inspección -->
          <div class="grid grid-cols-1 lg:grid-cols-12 gap-4 overflow-y-auto max-h-[62vh] pr-1 flex-grow">
            <!-- Cuadrícula (Grid) de Slots (8 cols) -->
            <div class="lg:col-span-8 card-glass border rounded-3xl p-4 flex flex-col gap-3 shadow-xl overflow-y-auto max-h-[60vh]">
              <div class="grid grid-cols-4 sm:grid-cols-5 md:grid-cols-6 gap-3">
                ${slots.map((item: any, idx: number) => {
                  const isSelected = selectedSlotIndex === idx;
                  const matchesTab = activeTab === 'all' || 
                    (activeTab === 'weapons' && item?.type === 'weapon') ||
                    (activeTab === 'consumables' && (item?.type === 'consumable' || item?.type === 'material')) ||
                    (activeTab === 'companions' && item?.type === 'companion');

                  const isDimmed = item !== null && !matchesTab;

                  return `
                    <div data-index="${idx}" class="inventory-slot relative aspect-square rounded-2xl border ${isSelected ? 'border-[var(--accent)] accent-glow' : 'border-[var(--border-color)]'} ${isDimmed ? 'opacity-40' : 'opacity-100'} app-bg flex flex-col items-center justify-center p-2 cursor-pointer hover:border-[var(--accent)] transition-all group select-none">
                      ${item ? `
                        <div class="text-xl md:text-2xl">${getItemIcon(item.itemId)}</div>
                        <div class="text-[9px] font-mono text-[var(--text-main)] font-bold truncate max-w-full mt-1 px-1">${item.name}</div>
                        ${item.quantity > 1 ? `
                          <div class="absolute bottom-1 right-1.5 bg-slate-950/80 accent-text text-[9px] font-mono font-bold px-1.5 py-0.5 rounded-md border border-[var(--border-color)]">
                            x${item.quantity}
                          </div>
                        ` : ''}
                        ${item.active || item.equipped ? `
                          <div class="absolute top-1 left-1.5 w-2 h-2 rounded-full accent-bg animate-pulse"></div>
                        ` : ''}
                      ` : `
                        <div class="text-[10px] font-mono text-[var(--text-muted)] opacity-30">${idx + 1}</div>
                      `}
                    </div>
                  `;
                }).join('')}
              </div>
            </div>

            <!-- Panel de Inspección Lateral (4 cols) -->
            <div class="lg:col-span-4 card-glass border rounded-3xl p-5 flex flex-col justify-between shadow-xl">
              ${selectedSlotIndex !== null && slots[selectedSlotIndex] ? (() => {
                const item = slots[selectedSlotIndex];
                const isCompanion = item.type === 'companion';
                const isCompanionActive = isCompanion && state.activeCompanions.includes(item.uid);

                return `
                  <div class="flex flex-col gap-4">
                    <div class="flex items-center justify-between border-b border-[var(--border-color)] pb-3">
                      <div class="font-['Orbitron'] font-bold text-sm accent-text">PANEL DE INSPECCIÓN</div>
                      <span class="text-[10px] font-mono accent-bg text-slate-950 px-2 py-0.5 rounded-full font-bold">${item.rarity}</span>
                    </div>

                    <div class="flex flex-col items-center text-center gap-2 py-2">
                      <div class="text-4xl p-3 card-glass border rounded-2xl">${getItemIcon(item.itemId)}</div>
                      <div class="font-['Orbitron'] font-bold text-base text-[var(--text-main)]">${item.name}</div>
                      <div class="text-xs font-mono text-[var(--text-muted)]">${item.details}</div>${item.quantity > 1 ? `<div class="text-xs font-mono accent-text font-bold">Cantidad disponible: ${item.quantity} (Máx stack: ${item.maxStack})</div>` : ''}
                    </div>

                    <div class="flex flex-col gap-2 pt-2">
                      ${isCompanion ? `
                        <button id="inspect-action-btn" class="w-full py-2.5 rounded-xl text-xs font-mono font-bold transition cursor-pointer ${isCompanionActive ? 'bg-red-500/20 border border-red-500/40 text-red-300' : 'accent-bg text-slate-950'}">
                          ${isCompanionActive ? 'Guardar Compañero' : 'Desplegar Compañero'}
                        </button>
                      ` : ''}

                      ${item.maxStack > 1 && item.quantity > 1 ? `
                        <button id="split-stack-btn" class="w-full py-2.5 card-glass border accent-border accent-text hover:accent-bg hover:text-slate-950 font-['Orbitron'] font-bold text-xs rounded-xl transition cursor-pointer">
                          Dividir Pila (Split)
                        </button>
                      ` : ''}

                      <button id="discard-item-btn" class="w-full py-2.5 bg-red-500/10 border border-red-500/30 text-red-400 hover:bg-red-500/20 font-['Orbitron'] font-bold text-xs rounded-xl transition cursor-pointer">
                        Descartar Ítem
                      </button>
                    </div>
                  </div>
                `;
              })() : `
                <div class="h-full flex flex-col items-center justify-center text-center text-xs font-mono text-[var(--text-muted)] gap-2 py-10">
                  <span class="text-2xl">🔍</span>
                  Selecciona un ítem en la cuadrícula para ver sus especificaciones técnicas y opciones de gestión.
                </div>
              `}
              <div class="text-[10px] font-mono text-[var(--text-muted)] text-center pt-3 border-t border-[var(--border-color)]">
                Arrastra o haz clic para mover entre slots
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Modal de División de Pila (Split) -->
      <div id="split-modal" class="hidden fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
        <div class="card-glass border rounded-3xl p-6 max-w-sm w-full shadow-2xl flex flex-col gap-4 text-center">
          <h3 class="font-['Orbitron'] font-bold text-sm accent-text">DIVIDIR PILA DE ÍTEMS</h3>
          <div id="split-item-name" class="text-xs font-mono text-[var(--text-main)]"></div>
          
          <div class="flex items-center justify-center gap-3 my-2">
            <button id="split-minus" class="w-10 h-10 card-glass border rounded-xl font-bold accent-text">-</button>
            <input id="split-input" type="number" min="1" value="1" class="w-20 text-center app-bg border border-[var(--border-color)] rounded-xl py-2 text-sm font-mono text-[var(--text-main)] focus:outline-none" />
            <button id="split-plus" class="w-10 h-10 card-glass border rounded-xl font-bold accent-text">+</button>
          </div>

          <div class="flex gap-2">
            <button id="cancel-split" class="flex-1 py-2.5 card-glass border border-[var(--border-color)] text-xs font-mono rounded-xl">Cancelar</button>
            <button id="confirm-split" class="flex-1 py-2.5 accent-bg text-slate-950 font-['Orbitron'] font-bold text-xs rounded-xl accent-glow">Confirmar</button>
          </div>
        </div>
      </div>
    `;

    // Event Listeners
    container.querySelector('#back-btn')?.addEventListener('click', onBack);

    container.querySelectorAll('.tab-btn').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        activeTab = (e.currentTarget as HTMLElement).getAttribute('data-tab')!;
        selectedSlotIndex = null;
        renderTemplate();
      });
    });

    container.querySelector('#expand-warehouse-btn')?.addEventListener('click', () => {
      const success = game.expandWarehouse();
      if (!success) alert('Nanitas insuficientes (Requiere 500) o almacén al límite.');
      renderTemplate();
    });

    // Gestión de Clic y Mover / Seleccionar Slots
    container.querySelectorAll('.inventory-slot').forEach((slotEl) => {
      const idx = parseInt(slotEl.getAttribute('data-index')!);

      slotEl.addEventListener('click', () => {
        if (selectedSlotIndex === null) {
          if (slots[idx] !== null) {
            selectedSlotIndex = idx;
            renderTemplate();
          }
        } else {
          if (selectedSlotIndex === idx) {
            selectedSlotIndex = null;
          } else {
            game.moveInventoryItem(selectedSlotIndex, idx);
            selectedSlotIndex = null;
          }
          renderTemplate();
        }
      });
    });

    // Acciones del Panel de Inspección
    const inspectActionBtn = container.querySelector('#inspect-action-btn');
    if (inspectActionBtn && selectedSlotIndex !== null) {
      inspectActionBtn.addEventListener('click', () => {
        const item = slots[selectedSlotIndex!];
        if (item && item.type === 'companion') {
          const success = game.toggleCompanionActive(item.uid);
          if (!success) alert('No hay slots de compañeros libres disponibles.');
          renderTemplate();
        }
      });
    }

    const discardBtn = container.querySelector('#discard-item-btn');
    if (discardBtn && selectedSlotIndex !== null) {
      discardBtn.addEventListener('click', () => {
        if (confirm('¿Estás seguro de descartar este ítem del almacén?')) {
          game.discardInventoryItem(selectedSlotIndex!);
          selectedSlotIndex = null;
          renderTemplate();
        }
      });
    }

    const splitBtn = container.querySelector('#split-stack-btn');
    const splitModal = container.querySelector('#split-modal');
    if (splitBtn && selectedSlotIndex !== null) {
      splitBtn.addEventListener('click', () => {
        const item = slots[selectedSlotIndex!];
        if (!item) return;
        const nameEl = container.querySelector('#split-item-name');
        const inputEl = container.querySelector('#split-input') as HTMLInputElement;
        if (nameEl) nameEl.textContent = item.name;
        if (inputEl) {
          inputEl.max = String(item.quantity - 1);
          inputEl.value = '1';
        }
        splitModal?.classList.remove('hidden');
      });

      container.querySelector('#cancel-split')?.addEventListener('click', () => {
        splitModal?.classList.add('hidden');
      });

      container.querySelector('#confirm-split')?.addEventListener('click', () => {
        const inputEl = container.querySelector('#split-input') as HTMLInputElement;
        const amount = parseInt(inputEl.value);
        const success = game.splitInventoryStack(selectedSlotIndex!, amount);
        if (!success) alert('No hay slots vacíos suficientes o cantidad inválida.');
        splitModal?.classList.add('hidden');
        renderTemplate();
      });
    }
  };

  renderTemplate();
}

function getItemIcon(itemId: string): string {
  if (itemId === 'key') return '🔑';
  if (itemId === 'upgradeCrystal') return '💎';
  if (itemId === 'commonCrate' || itemId === 'rareCrate' || itemId === 'epicCrate' || itemId === 'legendaryCrate') return '📦';
  if (itemId.startsWith('comp_') || itemId.includes('companion')) return '🤖';
  return '⚡';
}