import { auth } from '../firebase';
import { signOut } from 'firebase/auth';
import { FACTORY_COSTS } from '../gameLoop';
import { setTheme, getSavedTheme } from '../theme';
import { formatNumber } from '../utils';

export function renderGameHUD(
  container: HTMLElement,
  gameState: any,
  currentUser: any,
  onAction: (action: string, payload?: any) => void
) {
  const playerName = currentUser?.displayName || currentUser?.email?.split('@')[0] || 'Operativo';
  const currentTheme = getSavedTheme();

  container.innerHTML = `
    <div class="min-h-screen app-bg flex flex-col justify-between p-6 font-sans select-none relative overflow-hidden">
      <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-[var(--accent)]/10 via-[var(--bg-app)] to-[var(--bg-app)] pointer-events-none"></div>

      <!-- Top Bar -->
      <div class="relative z-10 flex flex-wrap justify-between items-center gap-4 card-glass border border-[var(--border-color)] rounded-2xl p-4 shadow-xl">
        <div class="flex items-center gap-3">
          <div class="w-3 h-3 rounded-full accent-bg accent-glow animate-pulse"></div>
          <div>
            <div class="text-xs font-mono text-[var(--text-muted)]">OPERATIVO ACTIVO</div>
            <div class="font-bold font-mono text-sm text-[var(--text-main)]">${playerName}</div>
          </div>
        </div>

        <div class="flex items-center gap-3">
          <!-- Selector de Tema -->
          <div class="relative">
            <select id="theme-select" aria-label="Seleccionar tema visual" class="app-bg border border-[var(--border-color)] rounded-xl px-3 py-2 text-xs font-mono text-[var(--text-main)] focus:outline-none focus:border-[var(--accent)] cursor-pointer">
              <option value="synthwave" ${currentTheme === 'synthwave' ? 'selected' : ''}>🌸 Synthwave</option>
              <option value="cyber" ${currentTheme === 'cyber' ? 'selected' : ''}>⚡ Cibernética</option>
              <option value="biomatrix" ${currentTheme === 'biomatrix' ? 'selected' : ''}>🌿 Bio-Matrix</option>
              <option value="nova" ${currentTheme === 'nova' ? 'selected' : ''}>☀️ Nova (Claro)</option>
            </select>
          </div>

          <button id="rankings-btn" class="px-4 py-2 card-glass border border-[var(--border-color)] rounded-xl text-xs font-mono accent-text hover:border-[var(--accent)] transition">
            🏆 Rankings
          </button>

          <button id="logout-btn" class="px-4 py-2 bg-red-500/10 border border-red-500/30 rounded-xl text-xs font-mono text-red-400 hover:bg-red-500/20 transition">
            Cerrar Sesión
          </button>
        </div>
      </div>

      <!-- Main Center Clicker & Stats -->
      <div class="relative z-10 flex flex-col md:flex-row items-center justify-center gap-10 my-auto py-8">
        <!-- Panel Central de Extracción con ancho estable para evitar saltos -->
        <div class="flex flex-col items-center gap-6 w-full max-w-md">
          <div class="text-center w-full">
            <div class="text-xs font-mono text-[var(--text-muted)] uppercase tracking-widest mb-1">Nanitas Extraídas</div>
            <div class="w-full flex justify-center items-center">
              <div id="nanites-display" class="text-4xl md:text-5xl font-['Orbitron'] font-black accent-text tracking-wider whitespace-nowrap">${formatNumber(gameState.nanites)}</div>
            </div>
            <div class="text-xs font-mono text-[var(--text-muted)] mt-1">+${formatNumber(gameState.passiveIncome)} / seg</div>
          </div>

          <button id="click-btn" class="w-48 h-48 rounded-full card-glass border-2 border-[var(--accent)] accent-glow flex flex-col items-center justify-center gap-2 transform active:scale-95 transition cursor-pointer group">
            <span class="text-5xl group-hover:scale-110 transition">⚡</span>
            <span class="font-['Orbitron'] font-black text-xs accent-text tracking-widest">EXTRAER</span>
          </button>
        </div>

        <!-- Panel de Fábricas / Mejoras -->
        <div class="card-glass border border-[var(--border-color)] rounded-2xl p-6 w-full max-w-md flex flex-col gap-4 shadow-2xl">
          <h3 class="font-['Orbitron'] font-bold text-sm accent-text tracking-wider border-b border-[var(--border-color)] pb-3">INFRAESTRUCTURA</h3>
          
          <div id="factories-list" class="flex flex-col gap-3">
            <!-- Drone -->
            <div class="flex items-center justify-between p-3 app-bg border border-[var(--border-color)] rounded-xl">
              <div>
                <div class="font-bold text-sm text-[var(--text-main)] font-mono">Dron Minero</div>
                <div class="text-xs text-[var(--text-muted)] font-mono">Nivel: ${gameState.factories.drone} (+1/s)</div>
              </div>
              <button data-buy="drone" class="px-4 py-2 accent-bg text-slate-950 font-['Orbitron'] font-bold text-xs rounded-lg hover:opacity-90 transition">
                Comprar (${formatNumber(Math.floor(FACTORY_COSTS.drone * Math.pow(1.15, gameState.factories.drone)))})
              </button>
            </div>

            <!-- Assembler -->
            <div class="flex items-center justify-between p-3 app-bg border border-[var(--border-color)] rounded-xl">
              <div>
                <div class="font-bold text-sm text-[var(--text-main)] font-mono">Ensamblador</div>
                <div class="text-xs text-[var(--text-muted)] font-mono">Nivel: ${gameState.factories.assembler} (+8/s)</div>
              </div>
              <button data-buy="assembler" class="px-4 py-2 accent-bg text-slate-950 font-['Orbitron'] font-bold text-xs rounded-lg hover:opacity-90 transition">
                Comprar (${formatNumber(Math.floor(FACTORY_COSTS.assembler * Math.pow(1.15, gameState.factories.assembler)))})
              </button>
            </div>

            <!-- Colossus -->
            <div class="flex items-center justify-between p-3 app-bg border border-[var(--border-color)] rounded-xl">
              <div>
                <div class="font-bold text-sm text-[var(--text-main)] font-mono">Coloso Cuántico</div>
                <div class="text-xs text-[var(--text-muted)] font-mono">Nivel: ${gameState.factories.colossus} (+40/s)</div>
              </div>
              <button data-buy="colossus" class="px-4 py-2 accent-bg text-slate-950 font-['Orbitron'] font-bold text-xs rounded-lg hover:opacity-90 transition">
                Comprar (${formatNumber(Math.floor(FACTORY_COSTS.colossus * Math.pow(1.15, gameState.factories.colossus)))})
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Footer info -->
      <div class="relative z-10 text-center text-xs font-mono text-[var(--text-muted)]">
        Cyber-Forge Modular Engine v1.0 • Sistema En Línea
      </div>
    </div>
  `;

  // Event Listeners
  const clickBtn = container.querySelector('#click-btn');
  clickBtn?.addEventListener('click', (e: any) => {
    const rect = clickBtn.getBoundingClientRect();
    const x = e.clientX || rect.left + rect.width / 2;
    const y = e.clientY || rect.top + rect.height / 2;
    onAction('click', { x, y });
  });

  container.querySelectorAll('[data-buy]').forEach(btn => {
    btn.addEventListener('click', () => {
      const type = btn.getAttribute('data-buy');
      onAction('buy', type);
    });
  });

  container.querySelector('#rankings-btn')?.addEventListener('click', () => {
    onAction('switch_tab', 'rankings');
  });

  container.querySelector('#logout-btn')?.addEventListener('click', async () => {
    await signOut(auth);
  });

  const themeSelect = container.querySelector('#theme-select') as HTMLSelectElement;
  themeSelect?.addEventListener('change', () => {
    const newTheme = themeSelect.value;
    setTheme(newTheme as any);
    onAction('switch_theme');
  });
}