export function getSavedTheme(): string {
  return localStorage.getItem('cyber_forge_theme') || 'synthwave';
}

export function setTheme(themeName: 'synthwave' | 'cyber' | 'biomatrix' | 'nova') {
  localStorage.setItem('cyber_forge_theme', themeName);
  document.body.setAttribute('data-theme', themeName);
}

export function applyTheme(themeName: string) {
  document.body.setAttribute('data-theme', themeName);
}