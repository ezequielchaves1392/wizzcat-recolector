import { db } from './firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';

const SAVE_VERSION = 4;
const MAX_BUFF_DURATION_MS = 8 * 60 * 60 * 1000;

export const WEAPON_BASE_COSTS = {
  blaster: 20,
  plasmaCannon: 150,
  quantumDisruptor: 1200
};

export const STORE_ITEMS = {
  key: { cost: 250, label: 'Llave de Cifrado' },
  upgradeCrystal: { cost: 60, label: 'Cristal de Mejora' },
  warehouseSlot: { cost: 500, label: 'Ampliar Almacén (+5 slots)' },
  commonCrate: { cost: 400, label: 'Caja Común' },
  rareCrate: { cost: 1200, label: 'Caja Rara' },
  epicCrate: { cost: 4500, label: 'Caja Épica' },
  legendaryCrate: { cost: 18000, label: 'Caja Legendaria' },
  clickBuff: { cost: 800, durationMs: 30 * 60 * 1000, label: 'Buff Clics x2 (30m)' },
  passiveBuff: { cost: 1500, durationMs: 60 * 60 * 1000, label: 'Buff Pasivo x2 + Excepción AFK (1h)' }
};

export const COMPANION_SLOT_COSTS = [0, 1000, 5000, 20000, 75000];

export async function createGameLoop(user: any, onUpdate: (state: any, isAfkPaused?: boolean) => void) {
  let state = {
    saveVersion: SAVE_VERSION,
    nanites: 100,
    passiveIncome: 0,
    totalClicks: 0,
    totalInfraestructure: 0,
    cratesOpened: 0,
    keys: 3,
    upgradeCrystals: 5,
    warehouseCapacity: 15,
    maxCompanionSlots: 1,
    crates: {
      common: 2,
      rare: 0,
      epic: 0,
      legendary: 0
    },
    weapons: {
      blaster: { level: 0, equipped: true },
      plasmaCannon: { level: 0, equipped: false },
      quantumDisruptor: { level: 0, equipped: false }
    },
    companions: [] as Array<{ id: string; name: string; type: 'click' | 'passive' | 'multiplier'; power: number; rarity: string }>,
    activeCompanions: [] as string[],
    warehouse: [] as Array<{ id: string; name: string; type: string; details: string; rarity: string }>,
    buffs: {
      clickBoostExpiresAt: 0,
      passiveBoostExpiresAt: 0
    }
  };

  let isAfk = false;
  let lastActiveTimestamp = Date.now();
  const AFK_THRESHOLD_MS = 45000;

  const userRef = doc(db, 'rankings', user.uid);

  try {
    const docSnap = await getDoc(userRef);
    if (docSnap.exists()) {
      const data = docSnap.data();
      state.saveVersion = SAVE_VERSION;
      state.nanites = data.score ?? 100;
      state.totalClicks = data.totalClicks ?? 0;
      state.totalInfraestructure = data.totalInfraestructure ?? 0;
      state.cratesOpened = data.cratesOpened ?? 0;
      state.keys = data.keys ?? 3;
      state.upgradeCrystals = data.upgradeCrystals ?? 5;
      state.warehouseCapacity = data.warehouseCapacity ?? 15;
      state.maxCompanionSlots = data.maxCompanionSlots ?? 1;
      state.crates = {
        common: data.crates?.common ?? 2,
        rare: data.crates?.rare ?? 0,
        epic: data.crates?.epic ?? 0,
        legendary: data.crates?.legendary ?? 0
      };
      state.weapons = data.weapons ?? state.weapons;
      state.companions = data.companions ?? [];
      state.activeCompanions = data.activeCompanions ?? [];
      state.warehouse = data.warehouse ?? [];
      state.buffs = {
        clickBoostExpiresAt: data.buffs?.clickBoostExpiresAt ?? 0,
        passiveBoostExpiresAt: data.buffs?.passiveBoostExpiresAt ?? 0
      };
      recalculatePassiveIncome();
    } else {
      await setDoc(userRef, {
        saveVersion: SAVE_VERSION,
        userId: user.uid,
        username: user.displayName || 'Operativo',
        score: state.nanites,
        totalClicks: 0,
        totalInfraestructure: 0,
        cratesOpened: 0,
        keys: state.keys,
        upgradeCrystals: state.upgradeCrystals,
        warehouseCapacity: state.warehouseCapacity,
        maxCompanionSlots: state.maxCompanionSlots,
        crates: state.crates,
        weapons: state.weapons,
        companions: state.companions,
        activeCompanions: state.activeCompanions,
        warehouse: state.warehouse,
        buffs: state.buffs,
        updatedAt: new Date()
      });
    }
  } catch (error) {
    console.error("Error al sincronizar con Firebase:", error);
  }

  function recalculatePassiveIncome() {
    let base = 0;
    // Drones ayudantes / asistencia pasiva proveniente de compañeros o armas pasivas
    state.activeCompanions.forEach(compId => {
      const comp = state.companions.find(c => c.id === compId);
      if (comp && comp.type === 'passive') {
        base += comp.power;
      }
    });

    if (Date.now() < state.buffs.passiveBoostExpiresAt) {
      base *= 2;
    }
    state.passiveIncome = base;
  }

  async function saveToFirebase() {
    if (!user) return;
    try {
      await setDoc(userRef, {
        saveVersion: SAVE_VERSION,
        userId: user.uid,
        username: user.displayName || 'Operativo',
        score: state.nanites,
        totalClicks: state.totalClicks,
        totalInfraestructure: state.totalInfraestructure,
        cratesOpened: state.cratesOpened,
        keys: state.keys,
        upgradeCrystals: state.upgradeCrystals,
        warehouseCapacity: state.warehouseCapacity,
        maxCompanionSlots: state.maxCompanionSlots,
        crates: state.crates,
        weapons: state.weapons,
        companions: state.companions,
        activeCompanions: state.activeCompanions,
        warehouse: state.warehouse,
        buffs: state.buffs,
        updatedAt: new Date()
      }, { merge: true });
    } catch (error) {
      console.error("Error al guardar en Firebase:", error);
    }
  }

  const handleVisibilityChange = () => {
    if (document.hidden) {
      isAfk = true;
    } else {
      const elapsed = Date.now() - lastActiveTimestamp;
      isAfk = elapsed > AFK_THRESHOLD_MS;
      lastActiveTimestamp = Date.now();
    }
  };

  const handleUserActivity = () => {
    lastActiveTimestamp = Date.now();
    if (isAfk) {
      isAfk = false;
      onUpdate(state, false);
    }
  };

  document.addEventListener('visibilitychange', handleVisibilityChange);
  window.addEventListener('mousemove', handleUserActivity);
  window.addEventListener('keydown', handleUserActivity);
  window.addEventListener('click', handleUserActivity);

  const saveInterval = setInterval(saveToFirebase, 15000);
  const handleUnload = () => { saveToFirebase(); };
  window.addEventListener('beforeunload', handleUnload);

  const gameInterval = setInterval(() => {
    recalculatePassiveIncome();
    const now = Date.now();
    const hasPassiveBuffActive = now < state.buffs.passiveBoostExpiresAt;
    const isEffectivelyAfk = isAfk && !hasPassiveBuffActive;

    if (isEffectivelyAfk) {
      onUpdate(state, true);
      return;
    }

    if (state.passiveIncome > 0) {
      state.nanites += state.passiveIncome;
      onUpdate(state, isAfk && hasPassiveBuffActive);
    }
  }, 1000);

  return {
    getState: () => state,
    isAfk: () => isAfk,
    click: () => {
      handleUserActivity();
      const now = Date.now();
      const isClickBuffActive = now < state.buffs.clickBoostExpiresAt;
      let multiplier = isClickBuffActive ? 2 : 1;

      // Calcular daño base de armas equipadas (cada nivel da +10% de daño, hasta +200% en nivel 20)
      let weaponDamageBonus = 1;
      Object.entries(state.weapons).forEach(([key, w]: [string, any]) => {
        if (w.equipped) {
          const baseDmg = key === 'blaster' ? 1 : key === 'plasmaCannon' ? 5 : 25;
          const levelMultiplier = 1 + (w.level * 0.10);
          weaponDamageBonus += baseDmg * levelMultiplier;
        }
      });

      // Compañeros de tipo click o multiplicador
      state.activeCompanions.forEach(compId => {
        const comp = state.companions.find(c => c.id === compId);
        if (comp) {
          if (comp.type === 'click') weaponDamageBonus += comp.power;
          if (comp.type === 'multiplier') multiplier += comp.power;
        }
      });

      const totalGain = Math.max(1, Math.floor(weaponDamageBonus * multiplier));
      state.nanites += totalGain;
      state.totalClicks += 1;
      onUpdate(state, isAfk);
    },
    buyWeaponLevel: (weaponKey: 'blaster' | 'plasmaCannon' | 'quantumDisruptor') => {
      handleUserActivity();
      const baseCost = WEAPON_BASE_COSTS[weaponKey];
      const weapon = state.weapons[weaponKey];
      if (!weapon || weapon.level >= 3) return false; // Solo se pueden comprar 3 niveles base directos en la tienda

      const cost = Math.floor(baseCost * Math.pow(1.5, weapon.level));
      if (state.nanites >= cost) {
        state.nanites -= cost;
        weapon.level += 1;
        onUpdate(state, isAfk);
        saveToFirebase();
        return true;
      }
      return false;
    },
    upgradeWeaponGacha: (weaponKey: 'blaster' | 'plasmaCannon' | 'quantumDisruptor') => {
      handleUserActivity();
      const weapon = state.weapons[weaponKey];
      if (!weapon || weapon.level >= 20) return { success: false, msg: 'Arma al nivel máximo (+200%).' };
      if (state.upgradeCrystals < 1) return { success: false, msg: 'Requiere al menos 1 Cristal de Mejora.' };

      state.upgradeCrystals -= 1;

      // Probabilidad de éxito disminuye conforme sube de nivel (ej. 90% en nivel 3 hasta 40% en nivel 19)
      const successChance = Math.max(40, 95 - (weapon.level * 2.5));
      const roll = Math.random() * 100;

      if (roll <= successChance) {
        weapon.level += 1;
        onUpdate(state, isAfk);
        saveToFirebase();
        return { success: true, msg: `¡Mejora exitosa! Arma ascendió al nivel ${weapon.level}.` };
      } else {
        // Falló: baja de nivel (si es mayor a 0 y mayor al nivel base comprado, o baja 1 nivel respetando mínimo 0)
        if (weapon.level > 0) {
          weapon.level -= 1;
        }
        onUpdate(state, isAfk);
        saveToFirebase();
        return { success: false, msg: `Fallo en el sintonizador. El arma retrocedió al nivel ${weapon.level}.` };
      }
    },
    expandWarehouse: () => {
      handleUserActivity();
      const cost = 500;
      if (state.nanites >= cost && state.warehouse.length < 50) {
        state.nanites -= cost;
        state.warehouseCapacity += 5;
        onUpdate(state, isAfk);
        saveToFirebase();
        return true;
      }
      return false;
    },
    unlockCompanionSlot: () => {
      handleUserActivity();
      if (state.maxCompanionSlots >= 5) return false;
      const cost = COMPANION_SLOT_COSTS[state.maxCompanionSlots];
      if (state.nanites >= cost) {
        state.nanites -= cost;
        state.maxCompanionSlots += 1;
        onUpdate(state, isAfk);
        saveToFirebase();
        return true;
      }
      return false;
    },
    toggleCompanionActive: (compId: string) => {
      handleUserActivity();
      const index = state.activeCompanions.indexOf(compId);
      if (index > -1) {
        state.activeCompanions.splice(index, 1);
      } else {
        if (state.activeCompanions.length < state.maxCompanionSlots) {
          state.activeCompanions.push(compId);
        } else {
          return false;
        }
      }
      recalculatePassiveIncome();
      onUpdate(state, isAfk);
      saveToFirebase();
      return true;
    },
    buyStoreItem: (itemKey: keyof typeof STORE_ITEMS) => {
      handleUserActivity();
      const item = STORE_ITEMS[itemKey];
      if (!item || state.nanites < item.cost) return false;

      state.nanites -= item.cost;

      if (itemKey === 'key') {
        state.keys += 1;
      } else if (itemKey === 'upgradeCrystal') {
        state.upgradeCrystals += 1;
      } else if (itemKey === 'warehouseSlot') {
        state.warehouseCapacity += 5;
      } else if (itemKey === 'commonCrate') {
        state.crates.common += 1;
      } else if (itemKey === 'rareCrate') {
        state.crates.rare += 1;
      } else if (itemKey === 'epicCrate') {
        state.crates.epic += 1;
      } else if (itemKey === 'legendaryCrate') {
        state.crates.legendary += 1;
      } else if (itemKey === 'clickBuff') {
        const now = Date.now();
        const currentExpires = Math.max(now, state.buffs.clickBoostExpiresAt);
        state.buffs.clickBoostExpiresAt = Math.min(currentExpires + item.durationMs, now + MAX_BUFF_DURATION_MS);
      } else if (itemKey === 'passiveBuff') {
        const now = Date.now();
        const currentExpires = Math.max(now, state.buffs.passiveBoostExpiresAt);
        state.buffs.passiveBoostExpiresAt = Math.min(currentExpires + item.durationMs, now + MAX_BUFF_DURATION_MS);
        recalculatePassiveIncome();
      }

      onUpdate(state, isAfk);
      saveToFirebase();
      return true;
    },
    openCrateBox: (crateType: 'common' | 'rare' | 'epic' | 'legendary') => {
      handleUserActivity();
      if (state.keys < 1 || state.crates[crateType] < 1) return null;

      state.keys -= 1;
      state.crates[crateType] -= 1;
      state.cratesOpened += 1;

      const roll = Math.random() * 100;
      let reward: { type: string; amount: number; label: string; itemData?: any };

      if (crateType === 'common') {
        if (roll < 50) reward = { type: 'nanites', amount: 300, label: '+300 Nanitas' };
        else if (roll < 80) {
          state.upgradeCrystals += 2;
          reward = { type: 'crystal', amount: 2, label: '+2 Cristales de Mejora' };
        } else {
          const comp = { id: 'comp_' + Math.random().toString(36).substring(2, 9), name: 'Dron Explorador', type: 'passive' as const, power: 2, rarity: 'Común' };
          if (state.warehouse.length < state.warehouseCapacity) {
            state.warehouse.push({ id: comp.id, name: comp.name, type: 'Compañero', details: '+2 Pasivo/s', rarity: comp.rarity });
            state.companions.push(comp);
            reward = { type: 'companion', amount: 1, label: 'Compañero: Dron Explorador (+2 Pasivo/s)' };
          } else {
            reward = { type: 'nanites', amount: 500, label: 'Almacén lleno: +500 Nanitas compensación' };
          }
        }
      } else if (crateType === 'rare') {
        if (roll < 40) {
          state.upgradeCrystals += 5;
          reward = { type: 'crystal', amount: 5, label: '+5 Cristales de Mejora' };
        } else if (roll < 80) {
          const comp = { id: 'comp_' + Math.random().toString(36).substring(2, 9), name: 'Artillero Táctico', type: 'click' as const, power: 10, rarity: 'Raro' };
          if (state.warehouse.length < state.warehouseCapacity) {
            state.warehouse.push({ id: comp.id, name: comp.name, type: 'Compañero', details: '+10 Daño de Clic', rarity: comp.rarity });
            state.companions.push(comp);
            reward = { type: 'companion', amount: 1, label: 'Compañero: Artillero Táctico (+10 Clic)' };
          } else {
            reward = { type: 'nanites', amount: 1500, label: 'Almacén lleno: +1,500 Nanitas' };
          }
        } else {
          state.crates.epic += 1;
          reward = { type: 'crate', amount: 1, label: '+1 Caja Épica' };
        }
      } else if (crateType === 'epic') {
        if (roll < 45) {
          state.upgradeCrystals += 15;
          reward = { type: 'crystal', amount: 15, label: '+15 Cristales de Mejora' };
        } else if (roll < 85) {
          const comp = { id: 'comp_' + Math.random().toString(36).substring(2, 9), name: 'IA Cuántica', type: 'multiplier' as const, power: 0.5, rarity: 'Épico' };
          if (state.warehouse.length < state.warehouseCapacity) {
            state.warehouse.push({ id: comp.id, name: comp.name, type: 'Compañero', details: '+50% Multiplicador Global', rarity: comp.rarity });
            state.companions.push(comp);
            reward = { type: 'companion', amount: 1, label: 'Compañero: IA Cuántica (+50% Mult)' };
          } else {
            reward = { type: 'nanites', amount: 5000, label: 'Almacén lleno: +5,000 Nanitas' };
          }
        } else {
          state.crates.legendary += 1;
          reward = { type: 'crate', amount: 1, label: '+1 Caja Legendaria' };
        }
      } else {
        // Legendary
        if (roll < 35) {
          state.upgradeCrystals += 40;
          reward = { type: 'crystal', amount: 40, label: '+40 Cristales de Mejora' };
        } else if (roll < 75) {
          const comp = { id: 'comp_' + Math.random().toString(36).substring(2, 9), name: 'Comandante Supremo', type: 'multiplier' as const, power: 2.0, rarity: 'Legendario' };
          if (state.warehouse.length < state.warehouseCapacity) {
            state.warehouse.push({ id: comp.id, name: comp.name, type: 'Compañero', details: '+200% Multiplicador Global', rarity: comp.rarity });
            state.companions.push(comp);
            reward = { type: 'companion', amount: 1, label: 'Compañero Supremo (+200% Mult)' };
          } else {
            reward = { type: 'nanites', amount: 20000, label: 'Almacén lleno: +20,000 Nanitas' };
          }
        } else {
          state.keys += 5;
          reward = { type: 'keys', amount: 5, label: '+5 Llaves de Cifrado' };
        }
      }

      recalculatePassiveIncome();
      onUpdate(state, isAfk);
      saveToFirebase();
      return reward;
    },
    cleanup: async () => {
      clearInterval(gameInterval);
      clearInterval(saveInterval);
      window.removeEventListener('beforeunload', handleUnload);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('mousemove', handleUserActivity);
      window.removeEventListener('keydown', handleUserActivity);
      window.removeEventListener('click', handleUserActivity);
      await saveToFirebase();
    }
  };
}